library(readxl)
library(dplyr)
library(prophet)
library(Metrics)
library(openxlsx)
library(xgboost)

setwd("/Users/qinchenyuan/Desktop/")
set.seed(123)


data <- read_excel("neodistotal_region_SDI_pop_old.xlsx")


param_grid <- expand.grid(
  changepoint_prior_scale = c(0.01, 0.05, 0.1, 0.5),
  changepoint_range = c(0.7, 0.8, 0.9, 0.95, 1.0)
)

analyze_location_prophet <- function(location_name, data) {
  cat("Processing:", location_name, "\n")
  
  Materdis <- data %>%
    filter(
      location == location_name,
      sex == "Both",
      age == "Birth",
      cause == "Neonatal preterm birth",
      metric == "Rate",
      year >= 1990 & year <= 2021
    ) %>%
    arrange(year)
  
  if (nrow(Materdis) < 30) return(NULL)
  if (any(is.na(Materdis$val)) || any(!is.finite(Materdis$val))) return(NULL)
  if (any(is.na(Materdis$SDI)) || any(!is.finite(Materdis$SDI))) return(NULL)
  if (any(is.na(Materdis$old)) || any(!is.finite(Materdis$old))) return(NULL)
  
  df <- data.frame(
    ds = as.Date(paste0(Materdis$year, "-01-01")),
    y = Materdis$val,
    SDI = Materdis$SDI,
    old = Materdis$old
  )
  

  train_df <- df %>% filter(format(ds, "%Y") %>% as.numeric() >= 1990 & format(ds, "%Y") %>% as.numeric() <= 2016)

  test_df <- df %>% filter(format(ds, "%Y") %>% as.numeric() >= 2017 & format(ds, "%Y") %>% as.numeric() <= 2019)
  
  future_years <- 2
  
  best_rmse <- Inf
  best_params <- NULL
  best_model <- NULL
  best_forecast_test <- NULL

  for (i in 1:nrow(param_grid)) {
    params <- param_grid[i, ]
    
    m <- prophet(
      yearly.seasonality = FALSE,
      daily.seasonality = FALSE,
      weekly.seasonality = FALSE,
      changepoint.prior.scale = params$changepoint_prior_scale,
      changepoint.range = params$changepoint_range,
      n.changepoints = 10,
      interval.width = 0.95
    )

    m <- add_regressor(m, "SDI")
    m <- add_regressor(m, "old")

    m <- fit.prophet(m, train_df)
    
    periods_test <- nrow(test_df)
    future_test <- make_future_dataframe(m, periods = periods_test, freq = "year")
    future_test <- future_test %>%
      left_join(df %>% select(ds, SDI, old), by = "ds")
    
    forecast_test <- predict(m, future_test)
    
    pred_test <- forecast_test %>%
      filter(format(ds, "%Y") %>% as.numeric() >= 2017 & format(ds, "%Y") %>% as.numeric() <= 2019) %>%
      pull(yhat)
    
    current_rmse <- rmse(test_df$y, pred_test)
    
    if (current_rmse < best_rmse) {
      best_rmse <- current_rmse
      best_params <- params
      best_model <- m
      best_forecast_test <- forecast_test
    }
  }
  

  train_all_df <- df %>% filter(format(ds, "%Y") %>% as.numeric() >= 1990 & format(ds, "%Y") %>% as.numeric() <= 2019)
  
  m_all <- prophet(
    yearly.seasonality = FALSE,
    daily.seasonality = FALSE,
    weekly.seasonality = FALSE,
    changepoint.prior.scale = best_params$changepoint_prior_scale,
    changepoint.range = best_params$changepoint_range,
    n.changepoints = 10,
    interval.width = 0.95
  )
  
  m_all <- add_regressor(m_all, "SDI")
  m_all <- add_regressor(m_all, "old")
  m_all <- fit.prophet(m_all, train_all_df)
  
  
  future_2020_2021 <- make_future_dataframe(m_all, periods = future_years, freq = "year")
  
  future_2020_2021 <- future_2020_2021 %>%
    left_join(df %>% select(ds, SDI, old), by = "ds")
  
  forecast_2020_2021 <- predict(m_all, future_2020_2021)
  

  fitted_df <- predict(m_all, train_all_df) %>%
    select(ds, yhat, yhat_lower, yhat_upper)
  

  pred_df <- forecast_2020_2021 %>%
    filter(format(ds, "%Y") %>% as.numeric() >= 2020 & format(ds, "%Y") %>% as.numeric() <= 2021) %>%
    select(ds, yhat, yhat_lower, yhat_upper)


  pred_test_final <- best_forecast_test %>%
    filter(format(ds, "%Y") %>% as.numeric() >= 2017 & format(ds, "%Y") %>% as.numeric() <= 2019) %>%
    pull(yhat)
  
  
  

  fitted_train_df <- predict(best_model, train_df)
  residuals_9016 <- train_df$y - fitted_train_df$yhat
  
  

  ts_data <- ts(Materdis$val, start = 1990, frequency = 1)
  train_1990_2016 <- window(ts_data, start = 1990, end = 2016)
  train_1994_2016 <- window(ts_data, start = 1994, end = 2016)
  test_data <- window(ts_data, start = 2017, end = 2019)
  train_1990_2019 <- window(ts_data, start = 1990, end = 2019)
  test_2020_2021 <- window(ts_data, start = 2020, end = 2021)
  
 
  
  res_train <- as.numeric(train_df$y - fitted_train_df$yhat)
  res_test <- as.numeric(test_df$y - pred_test_final) 
  
  res_all <- c(res_train, res_test)
  SDI_all <- Materdis$SDI  #！！！！
  old_all <- Materdis$old#！！！！
  
  
  

  create_lag_features <- function(x, lag = 4) {
    df <- tibble(Value = as.numeric(x))
    for (i in 1:lag) {
      df <- df %>% mutate(!!paste0("lag_", i) := dplyr::lag(Value, n = i))
    }
    return(df)
  }
  
  lag <- 4

  res_all_lagged <- create_lag_features(res_all, lag = lag) %>% na.omit()
  

  total_length <- length(res_all)
  train_length <- length(res_train)
  test_length <- length(res_test)
  

  SDI_all_lagged <- SDI_all[(lag + 1):total_length]
  old_all_lagged <- old_all[(lag + 1):total_length]
  

  train_idx <- 1:(train_length - lag)
  test_idx <- (train_length - lag + 1):(train_length - lag + test_length)
  

  X_train <- as.matrix(cbind(SDI = SDI_all_lagged[train_idx],
                             old = old_all_lagged[train_idx],
                             res_all_lagged[train_idx, -1]))
  y_train <- res_all_lagged$Value[train_idx]
  

  X_test <- as.matrix(cbind(SDI = SDI_all_lagged[test_idx],
                            old = old_all_lagged[test_idx],
                            res_all_lagged[test_idx, -1]))
  

  dtrain <- xgb.DMatrix(data = X_train, label = y_train)
  dtest <- xgb.DMatrix(data = X_test)
  


  coarse_param_grid <- expand.grid(
    eta = c(0.01, 0.05, 0.1),
    max_depth = c(3, 5, 7),
    subsample = c(0.6, 0.8, 1),
    colsample_bytree = c(0.6, 0.8, 1),
    KEEP.OUT.ATTRS = FALSE,
    stringsAsFactors = FALSE
  )

  cv_rmse <- function(params, dtrain) {
    cv <- xgb.cv(
      params = params,
      data = dtrain,
      nrounds = 100,
      nfold = 5,
      showsd = TRUE,
      early_stopping_rounds = 10,
      maximize = FALSE,
      verbose = 0
    )
    return(min(cv$evaluation_log$test_rmse_mean))
  }
  

  best_rmse <- Inf
  best_params <- list()
  set.seed(123)
  for (i in 1:nrow(coarse_param_grid)) {
    params <- list(
      objective = "reg:squarederror",
      eta = coarse_param_grid$eta[i],
      max_depth = coarse_param_grid$max_depth[i],
      subsample = coarse_param_grid$subsample[i],
      colsample_bytree = coarse_param_grid$colsample_bytree[i],
      seed = 123
    )
    rmse_val <- cv_rmse(params, dtrain)
    if (rmse_val < best_rmse) {
      best_rmse <- rmse_val
      best_params <- params
    }
  }

  fine_param_grid <- expand.grid(
    eta = seq(max(0.001, best_params$eta - 0.02), min(0.3, best_params$eta + 0.02), by = 0.01),
    max_depth = unique(pmax(1, c(best_params$max_depth - 1, best_params$max_depth, best_params$max_depth + 1))),
    subsample = seq(max(0.5, best_params$subsample - 0.1), min(1, best_params$subsample + 0.1), by = 0.1),
    colsample_bytree = seq(max(0.5, best_params$colsample_bytree - 0.1), min(1, best_params$colsample_bytree + 0.1), by = 0.1),
    KEEP.OUT.ATTRS = FALSE,
    stringsAsFactors = FALSE
  )
  

  set.seed(123)
  for (i in 1:nrow(fine_param_grid)) {
    params <- list(
      objective = "reg:squarederror",
      eta = fine_param_grid$eta[i],
      max_depth = fine_param_grid$max_depth[i],
      subsample = fine_param_grid$subsample[i],
      colsample_bytree = fine_param_grid$colsample_bytree[i]
    )
    rmse_val <- cv_rmse(params, dtrain)
    if (rmse_val < best_rmse) {
      best_rmse <- rmse_val
      best_params <- params
    }
  }
  

  set.seed(123)
  xgb_model <- xgb.train(params = best_params, data = dtrain, nrounds = 50, verbose = 0)
  
  residuals_pred <- predict(xgb_model, dtest)
  

  final_predictions <- as.numeric(pred_test_final + residuals_pred)
  
  rmse_test <- sqrt(mean((final_predictions - test_data)^2))
  mae_test <- mean(abs(final_predictions - test_data))
  mape_test <- mean(abs((final_predictions - test_data)/test_data)) * 100
  
  

  fitted_train_df <- predict(best_model, train_df)


  fitted_xgb_9416 <- predict(xgb_model, dtrain)
  fitted_Prophet9016 <- fitted_train_df$yhat
  fitted_Prophet_9416 <- fitted_Prophet9016[5:27]  
  final_fitted9416 <- fitted_Prophet_9416 + fitted_xgb_9416
  

  white_noise <- FALSE
  residuals_combined <- train_1994_2016 - final_fitted9416
  lb_test <- Box.test(residuals_combined, lag = 5, type = "Ljung-Box")
  white_noise <- lb_test$p.value > 0.05
  
  
  
 
  predictions_2020_2021 <- rep(NA, 2)
  
  
  fitted_df_y <- fitted_df$yhat
  residuals_train_full <- as.numeric(train_1990_2019 - fitted_df_y)
  SDI_train_full <- Materdis$SDI[Materdis$year <= 2019]
  old_train_full <- Materdis$old[Materdis$year <= 2019]
  
  lag <- 4

  residuals_train_full_lagged <- create_lag_features(residuals_train_full, lag = lag) %>% na.omit()
  
  total_full_length <- length(residuals_train_full)
  
  

  SDI_train_lagged <- SDI_train_full[(lag + 1):total_full_length]
  old_train_lagged <- old_train_full[(lag + 1):total_full_length]
  
 
  lagged_matrix <- residuals_train_full_lagged[, -1] %>% mutate(across(everything(), as.numeric))
  X_train_full <- as.matrix(cbind(SDI = SDI_train_lagged,
                                  old = old_train_lagged,
                                  lagged_matrix))
  y_train_full <- residuals_train_full_lagged$Value
  
  
  
  n_bootstrap <- 1000
  future_steps <- 2
  future_SDI <- Materdis$SDI[Materdis$year >= 2020 & Materdis$year <= 2021]
  future_old <- Materdis$old[Materdis$year >= 2020 & Materdis$year <= 2021]

  bootstrap_preds_future <- matrix(NA, nrow = n_bootstrap, ncol = future_steps)
  bootstrap_fitted_train <- matrix(NA, nrow = n_bootstrap, ncol = nrow(X_train_full))
  
  set.seed(123)
  for (b in 1:n_bootstrap) {

    boot_idx <- sample(1:nrow(X_train_full), size = nrow(X_train_full), replace = TRUE)

    dtrain_boot <- xgb.DMatrix(data = X_train_full[boot_idx, ], label = y_train_full[boot_idx])

    xgb_model_boot <- xgb.train(
      params = best_params, 
      data = dtrain_boot, 
      nrounds = 50, 
      verbose = 0)
    

    dtrain_full <- xgb.DMatrix(data = X_train_full, label = y_train_full)
    fitted_vals <- predict(xgb_model_boot, newdata = dtrain_full)
    bootstrap_fitted_train[b, ] <- fitted_vals 
    
    

    preds <- numeric(future_steps)
    lag_values <- tail(residuals_train_full, lag)
    
    for (i in 1:future_steps) {
      x_input <- c(SDI = future_SDI[i],
                   old = future_old[i],
                   lag_values)
      preds[i] <- predict(xgb_model_boot, matrix(x_input, nrow = 1))
      lag_values <- c(tail(lag_values, lag - 1), preds[i])
    }
    bootstrap_preds_future[b, ] <- preds
  }
  

  pred_xgb_future <- colMeans(bootstrap_preds_future)
  xgb_lower_future <- apply(bootstrap_preds_future, 2, quantile, probs = 0.025)
  xgb_upper_future <- apply(bootstrap_preds_future, 2, quantile, probs = 0.975)
  se_xgb_future <- (xgb_upper_future - xgb_lower_future) / (2 * 1.96)
  
  se_prophet_future <- (pred_df$yhat_upper - pred_df$yhat_lower) / (2 * 1.96)
  
  predictions_2020_2021 <- as.numeric(pred_df$yhat + pred_xgb_future)
  se_combined_future <- sqrt(se_prophet_future^2 + se_xgb_future^2)
  combined_lower_future <- predictions_2020_2021 - 1.96 * se_combined_future
  combined_upper_future <- predictions_2020_2021 + 1.96 * se_combined_future
  

  
  fitted_prophet_values <- fitted_df$yhat[5:30]  
  
  fitted_train_mean <- colMeans(bootstrap_fitted_train)

  fitted_xgb_values <- fitted_train_mean

  fitted_values <- as.numeric(fitted_prophet_values + fitted_xgb_values) 

  combined_lower_fit <- rep(NA, length(fitted_values))
  combined_upper_fit <- rep(NA, length(fitted_values))
  
  

  
  years <- 1994:2021
  
  all_predictions <- c(as.numeric(fitted_values), as.numeric(predictions_2020_2021))
  all_prelower <- c(as.numeric(combined_lower_fit), as.numeric(combined_lower_future))
  all_preupper <- c(as.numeric(combined_upper_fit), as.numeric(combined_upper_future))
  
  
  actual_val <- Materdis$val[Materdis$year %in% years]
  actual_upper <- Materdis$upper[Materdis$year %in% years]
  actual_lower <- Materdis$lower[Materdis$year %in% years]
  all_SDI <- Materdis$SDI[Materdis$year %in% years]
  all_old <- Materdis$old[Materdis$year %in% years]
  
  RMSE_all <- rep(rmse_test, length(years))
  MAE_all <- rep(mae_test, length(years))
  MAPE_all <- rep(mape_test, length(years))
  white_noise <- rep(white_noise, length(years)) 
  
  
  
  
  results_df <- data.frame(
    location = location_name,
    sex = "Both",
    age = "Birth",
    cause = "Neonatal preterm birth",
    year = years,
    val = actual_val,
    upper = actual_upper,
    lower = actual_lower,
    SDI = all_SDI,
    #  old = all_old,
    old = all_old,
    prediction_proXGB = all_predictions,
    preupper_proXGB = all_preupper,
    prelower_proXGB = all_prelower,
    RMSE_proXGB = RMSE_all,
    MAE_proXGB = MAE_all,
    MAPE_proXGB = MAPE_all,
    noise_proXGB = white_noise
  )
  
  predictions_test_df <- data.frame(
    location = location_name,
    year = 2017:2019,
    prediction_2017_2019 = final_predictions
  )
  
  return(list(full_results = results_df, predictions_test_only = predictions_test_df))
}

locations <- unique(data$location)
all_results <- list()
all_predictions_test <- list()

for (loc in locations) {
  res <- analyze_location_prophet(loc, data)
  if (!is.null(res)) {
    all_results[[loc]] <- res$full_results
    all_predictions_test[[loc]] <- res$predictions_test_only
  }
}

final_results <- bind_rows(all_results)


final_results$sig_proXGB <- ifelse(
  final_results$val >= final_results$prelower_proXGB & final_results$val <= final_results$preupper_proXGB,
  0, 1)

final_results$change_proXGB <- ifelse(
  final_results$val > final_results$prediction_proXGB, 1,
  ifelse(final_results$val < final_results$prediction_proXGB, -1, 0))


final_results <- final_results %>%
  mutate(rc_proXGB = (val - prediction_proXGB) / prediction_proXGB * 100)


lag <- 4
final_results_all <- final_results %>%
  filter(year >= 1990 + lag & year <= 2021)

final_results_2021 <- final_results %>%
  filter(year >= 2020 & year <= 2021)


final_predictions_test <- bind_rows(all_predictions_test)


write.xlsx(final_results_all, ".xlsx", rowNames = FALSE)
write.xlsx(final_results_2021, file = ".xlsx", rowNames = FALSE)

