
#########2020-2021######

setwd("/Users/qinchenyuan/Desktop/XXXX")

library(readxl)
library(dplyr)
library(Metrics)
library(openxlsx)
library(purrr)


Arima <- read_excel(".xlsx")
AXGB <- read_excel(".xlsx")
XGB <- read_excel(".xlsx")
Prophet <- read_excel(".xlsx")
ProXGB <- read_excel(".xlsx")


Arima <- Arima %>%
  mutate(model_arima = "ARIMA")
AXGB <- AXGB %>%
  mutate(model_axgb = "ARIMA+XGBoost")
XGB <- XGB %>%
  mutate(model_XGB = "XGBoost")
Prophet <- Prophet %>%
  mutate(model_prophet = "Prophet")
ProXGB <- ProXGB %>%
  mutate(model_proXGB = "Prophet+XGBoost")




data <- read_excel("2021region.xlsx")

data <- data %>%
  mutate(age = "Birth",
         cause = "Neonatal preterm birth",
         sex= "Both")


data1 <- Arima %>%
  select(location, sex, age, cause, year,val, upper, lower, SDI, old) 


data2 <- data %>%
  left_join(data1, by = c("location","sex","age", "cause", "year"))


#####data3#####
data3 <- data2 %>%
  left_join(Arima, by = c("location","sex","age", "cause", "year","val","upper","lower", "SDI", "old"))%>%
  left_join(AXGB, by = c("location","sex","age", "cause", "year","val","upper","lower", "SDI", "old"))%>%
  left_join(XGB, by = c("location","sex","age", "cause", "year","val","upper","lower", "SDI", "old"))%>%
  left_join(Prophet, by = c("location","sex","age", "cause", "year","val","upper","lower", "SDI", "old"))%>%
  left_join(ProXGB, by = c("location","sex","age", "cause", "year","val","upper","lower", "SDI", "old"))


data4 <- data3 



suffixes <- c("_arima", "_axgb", "_XGB", "_prophet", "_proXGB")


for (suf in suffixes) {

  noise_col <- paste0("noise", suf)
  

  model_cols <- grep(paste0(suf, "$"), names(data4), value = TRUE)
  model_cols <- setdiff(model_cols, noise_col) 
  
  data4 <- data4 %>%
    mutate(across(all_of(model_cols),
                  ~ if_else(get(noise_col), ., NA),
                  .names = "{.col}"))
} 



for (suf in suffixes) {
  mae_col <- paste0("MAE", suf)
  rounded_col <- paste0("rounded_MAE", suf)
  if (mae_col %in% names(data4)) {
    data4[[rounded_col]] <- round(data4[[mae_col]], 1)
  }
}


select_best_model <- function(row) {
  mae_vals <- sapply(suffixes, function(suf) {
    col <- paste0("rounded_MAE", suf)
    if (col %in% names(row)) as.numeric(row[[col]]) else NA
  })
  
  if (all(is.na(mae_vals))) return(NA)
  
  min_mae <- min(mae_vals, na.rm = TRUE)
  candidates <- suffixes[which(mae_vals == min_mae)]
  
  if (length(candidates) == 1) return(candidates)
  
  rmse_vals <- sapply(candidates, function(suf) {
    col <- paste0("RMSE", suf)
    if (col %in% names(row)) as.numeric(row[[col]]) else Inf
  })
  
  best <- candidates[which.min(rmse_vals)]
  return(best)
}


library(purrr)
data4$best_suffix <- map_chr(1:nrow(data4), function(i) select_best_model(data4[i, ]))
any(is.na(data4$best_suffix)) 


final_vars <- c( "model", "prediction", "preupper", "prelower", "RMSE", "MAE", "MAPE","sig","change","rc")

for (var in final_vars) {
  data4[[paste0(var, "_final")]] <- NA
  for (suf in suffixes) {
    target_col <- paste0(var, suf)
    final_col <- paste0(var, "_final")
    data4[[final_col]] <- ifelse(data4$best_suffix == suf, data4[[target_col]], data4[[final_col]])
  }
}

data_final <- data4 %>%
  select(location, sex, age, cause, year,val, upper, lower, SDI, old,model_final, prediction_final, preupper_final, prelower_final, RMSE_final, MAE_final, MAPE_final, sig_final, change_final, rc_final
) 



data_total <- data_final %>%
  left_join(data3, by = c("location","sex","age", "cause", "year","val","upper","lower", "SDI", "old"))





write.xlsx(data_final, file = ".xlsx", rowNames = FALSE)
write.xlsx(data_total, file = ".xlsx", rowNames = FALSE)




#########1994-2021######
setwd("/Users/qinchenyuan/Desktop/")

library(readxl)
library(dplyr)
library(Metrics)
library(openxlsx)
library(purrr)

# 读取 Excel 文件
Arima <- read_excel(".xlsx")
AXGB <- read_excel(".xlsx")
XGB <- read_excel(".xlsx")
Prophet <- read_excel(".xlsx")
ProXGB <- read_excel(".xlsx")


Arima <- Arima %>%
  mutate(model_arima = "ARIMA")
AXGB <- AXGB %>%
  mutate(model_axgb = "ARIMA+XGBoost")
XGB <- XGB %>%
  mutate(model_XGB = "XGBoost")
Prophet <- Prophet %>%
  mutate(model_prophet = "Prophet")
ProXGB <- ProXGB %>%
  mutate(model_proXGB = "Prophet+XGBoost")




data <- read_excel("allregion.xlsx")

data <- data %>%
  mutate(age = "Birth",
         cause = "Neonatal preterm birth",
         sex= "Both")


data1 <- Arima %>%
  select(location, sex, age, cause, year,val, upper, lower, SDI, old) 


data2 <- data %>%
  left_join(data1, by = c("location","sex","age", "cause", "year"))



data3 <- data2 %>%
  left_join(Arima, by = c("location","sex","age", "cause", "year","val","upper","lower", "SDI", "old"))%>%
  left_join(AXGB, by = c("location","sex","age", "cause", "year","val","upper","lower", "SDI", "old"))%>%
  left_join(XGB, by = c("location","sex","age", "cause", "year","val","upper","lower", "SDI", "old"))%>%
  left_join(Prophet, by = c("location","sex","age", "cause", "year","val","upper","lower", "SDI", "old"))%>%
  left_join(ProXGB, by = c("location","sex","age", "cause", "year","val","upper","lower", "SDI", "old"))



data4 <- data3

suffixes <- c("_arima", "_axgb", "_XGB", "_prophet", "_proXGB")


for (suf in suffixes) {

  noise_col <- paste0("noise", suf)
  

  model_cols <- grep(paste0(suf, "$"), names(data4), value = TRUE)
  model_cols <- setdiff(model_cols, noise_col)  
  

  data4 <- data4 %>%
    mutate(across(all_of(model_cols),
                  ~ if_else(get(noise_col), ., NA),
                  .names = "{.col}"))
} 


for (suf in suffixes) {
  mae_col <- paste0("MAE", suf)
  rounded_col <- paste0("rounded_MAE", suf)
  if (mae_col %in% names(data4)) {
    data4[[rounded_col]] <- round(data4[[mae_col]], 1)
  }
}


select_best_model <- function(row) {
  mae_vals <- sapply(suffixes, function(suf) {
    col <- paste0("rounded_MAE", suf)
    if (col %in% names(row)) as.numeric(row[[col]]) else NA
  })
  
  if (all(is.na(mae_vals))) return(NA)
  
  min_mae <- min(mae_vals, na.rm = TRUE)
  candidates <- suffixes[which(mae_vals == min_mae)]
  
  if (length(candidates) == 1) return(candidates)
  
  rmse_vals <- sapply(candidates, function(suf) {
    col <- paste0("RMSE", suf)
    if (col %in% names(row)) as.numeric(row[[col]]) else Inf
  })
  
  best <- candidates[which.min(rmse_vals)]
  return(best)
}


library(purrr)
data4$best_suffix <- map_chr(1:nrow(data4), function(i) select_best_model(data4[i, ]))
any(is.na(data4$best_suffix))  
final_vars <- c( "model", "prediction", "preupper", "prelower", "RMSE", "MAE", "MAPE","sig","change","rc")

for (var in final_vars) {
  data4[[paste0(var, "_final")]] <- NA
  for (suf in suffixes) {
    target_col <- paste0(var, suf)
    final_col <- paste0(var, "_final")
    data4[[final_col]] <- ifelse(data4$best_suffix == suf, data4[[target_col]], data4[[final_col]])
  }
}


data_final <- data4 %>%
  select(location, sex, age, cause, year,val, upper, lower, SDI, old,model_final, prediction_final, preupper_final, prelower_final, RMSE_final, MAE_final, MAPE_final, sig_final, change_final, rc_final
  ) 



data_total <- data_final %>%
  left_join(data3, by = c("location","sex","age", "cause", "year","val","upper","lower", "SDI", "old"))




write.xlsx(data_final, file = ".xlsx", rowNames = FALSE)
write.xlsx(data_total, file = ".xlsx", rowNames = FALSE)





