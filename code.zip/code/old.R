setwd("/Users/qinchenyuan/Desktop/XXXX")
library(dplyr)
library(forecast)
library(readxl)
library(openxlsx)
library(tidyr)


df_old <- read_excel("old_preg9019.xlsx")%>%
  select(location, year, old)


old_forecast <- data.frame(location = character(),
                           year = integer(),
                           old = double())

locations <- unique(df_old$location)

for (loc in locations) {
  df_loc <- df_old %>% filter(location == loc) %>% arrange(year)
  

  if (nrow(df_loc) < 5) next

  old_ts <- ts(df_loc$old, start = min(df_loc$year), frequency = 1)
  

  fit <- auto.arima(old_ts, ic = "aic", method = "ML")
  
  

  fcast <- forecast(fit, h = 2)
  

  old_forecast <- rbind(
    old_forecast,
    data.frame(location = loc,
               year = 2020:2021,
               old = as.numeric(fcast$mean))
  )
}


df_complete <- bind_rows(
  df_old %>% select(location, year, old),
  old_forecast
) %>% arrange(location, year)


write.xlsx(df_complete, file = "old_1990_2021_forecast.xlsx", overwrite = TRUE)


non_white_noise <- data.frame(location = character(),
                              p_value = double(),
                              stringsAsFactors = FALSE)

for (loc in locations) {
  df_loc <- df_old %>% filter(location == loc) %>% arrange(year)
  
  if (nrow(df_loc) < 5) next
  
  old_ts <- ts(df_loc$old, start = min(df_loc$year), frequency = 1)
  
  fit <- auto.arima(old_ts, ic = "aic", method = "ML")
  

  lb_test <- Box.test(fit$residuals, lag = 10, type = "Ljung-Box")
  

  if (lb_test$p.value <= 0.05) {
    non_white_noise <- rbind(non_white_noise,
                             data.frame(location = loc,
                                        p_value = lb_test$p.value))
  }
}

print(non_white_noise)
