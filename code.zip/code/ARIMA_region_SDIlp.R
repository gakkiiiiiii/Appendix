setwd("/Users/qinchenyuan/Desktop/XXXXX")


if (!require("readxl")) install.packages("readxl", dependencies=TRUE)
if (!require("dplyr")) install.packages("dplyr", dependencies=TRUE)
if (!require("forecast")) install.packages("forecast", dependencies=TRUE)
if (!require("Metrics")) install.packages("Metrics", dependencies=TRUE)
if (!require("openxlsx")) install.packages("openxlsx", dependencies=TRUE)

library(readxl)
library(dplyr)
library(forecast)
library(Metrics)
library(openxlsx)


data <- read_excel("neodistotal_region_SDI_pop_old.xlsx")


model_params_list <- list()

analyze_location <- function(location_name, data) {
  cat("Processing:", location_name, "\n")
  
  Materdis <- data %>%
    filter(
      location == location_name,
      age == "Birth",
      cause == "Neonatal preterm birth",
      metric == "Rate",
      year >= 1990 & year <= 2021
    ) %>%
    arrange(year)
  
  if (nrow(Materdis) < 30) return(NULL)
  if (any(is.na(Materdis$val)) || any(!is.finite(Materdis$val))) return(NULL)
  if (any(is.na(Materdis$SDI)) || any(!is.finite(Materdis$SDI))) return(NULL)
  
  ts_data <- ts(Materdis$val, start = c(1990, 1), frequency = 1)
  train_1990_2016 <- window(ts_data, start = c(1990), end = c(2016))
  train_1990_2019 <- window(ts_data, start = c(1990), end = c(2019))
  test_data <- window(ts_data, start = c(2017), end = c(2019))
  
  SDI_1990_2016 <- Materdis %>% filter(year <= 2016) %>% select(SDI, old) %>% as.matrix()
  SDI_1990_2019 <- Materdis %>% filter(year >= 1990 & year <= 2019) %>% select(SDI, old) %>% as.matrix()
  SDI_test <- Materdis %>% filter(year >= 2017 & year <= 2019) %>% select(SDI, old) %>% as.matrix()
  SDI_2020_2021 <- Materdis %>% filter(year >= 2020 & year <= 2021) %>% select(SDI, old) %>% as.matrix()

  model_arima <- auto.arima(train_1990_2016, xreg = SDI_1990_2016, seasonal = FALSE,
                            ic = "aic", method = "ML", stepwise = FALSE,
                            trace = FALSE, approximation = FALSE)
  
  forecast_test <- forecast(model_arima, xreg = SDI_test, h = length(test_data), level = 95)
  predictions_test <- forecast_test$mean
  

  rmse <- sqrt(mean((predictions_test - test_data)^2))
  mae <- mean(abs(predictions_test - test_data))
  mape <- mean(abs((predictions_test - test_data) / test_data)) * 100
  

  model_order <- arimaorder(model_arima)
  model_coef <- coef(model_arima)
  
  model_params_df <- data.frame(
    location = location_name,
    p = model_order["p"],
    d = model_order["d"],
    q = model_order["q"],
    coefficient = names(model_coef),
    value = as.numeric(model_coef)
  )
  model_params_list[[location_name]] <<- model_params_df
  

  model_fixed <- tryCatch({
    Arima(train_1990_2019,
          order = model_order[c("p", "d", "q")],
          xreg = SDI_1990_2019,
          method = "ML")
  }, error = function(e) {
    cat("Model fitting failed for", location_name, ":", conditionMessage(e), "\n")
    return(NULL)
  })
  
  fitted_values <- rep(NA, length(1990:2019))
  predictions_2020_2021 <- rep(NA, 4)
  upper_fitted <- lower_fitted <- rep(NA, length(1990:2019))
  forecast_2020_2021_upper <- forecast_2020_2021_lower <- rep(NA, 4)
  white_noise <- FALSE
  
  if (!is.null(model_fixed)) {
 
    forecast_2020_2021 <- forecast(model_fixed, xreg = SDI_2020_2021, h = 4, level = 95)
    predictions_2020_2021 <- forecast_2020_2021$mean
    
    fitted_values <- fitted(model_fixed)
    residuals <- residuals(model_fixed)
    se_fit <- sqrt(mean(residuals^2))
    z_value <- 1.96
    upper_fitted <- fitted_values + z_value * se_fit
    lower_fitted <- fitted_values - z_value * se_fit
    forecast_2020_2021_upper <- forecast_2020_2021$upper[, 1]
    forecast_2020_2021_lower <- forecast_2020_2021$lower[, 1]
  

    residuals_new <- residuals(model_arima)
    lb_test <- Box.test(residuals_new, lag = 5, type = "Ljung-Box")
    white_noise <- lb_test$p.value > 0.05
  }
  
  years <- 1990:2021
  all_predictions <- c(as.numeric(fitted_values), as.numeric(predictions_2020_2021))
  all_preupper <- c(as.numeric(upper_fitted), as.numeric(forecast_2020_2021_upper))
  all_prelower <- c(as.numeric(lower_fitted), as.numeric(forecast_2020_2021_lower))
  
  RMSE_all <- rep(rmse, length(years))
  MAE_all <- rep(mae, length(years))
  MAPE_all <- rep(mape, length(years))
  white_noise <- rep(white_noise, length(years))
  
  actual_val <- Materdis$val[Materdis$year %in% years]
  actual_upper <- Materdis$upper[Materdis$year %in% years]
  actual_lower <- Materdis$lower[Materdis$year %in% years]
  all_SDI <- Materdis$SDI[Materdis$year %in% years]
  all_old <- Materdis$old[Materdis$year %in% years]
  
  results_df <- data.frame(
    location = location_name,
    sex = "Both",
    age = "Birth",
    cause = "Neonatal preterm birth",
    year = years,
    val = actual_val,
    upper = actual_upper,
    lower = actual_lower,
    SDI = all_SDI,
    old = all_old,
    prediction_arima = all_predictions,
    preupper_arima = all_preupper,
    prelower_arima = all_prelower,
    RMSE_arima = RMSE_all,
    MAE_arima = MAE_all,
    MAPE_arima = MAPE_all,
    noise_arima = white_noise
  )
  
  predictions_test_df <- data.frame(
    location = location_name,
    year = 2017:2019,
    prediction_2017_2019 = as.numeric(predictions_test)
  )
  
  return(list(full_results = results_df, predictions_test_only = predictions_test_df))
}


locations <- unique(data$location)
all_results <- list()
all_predictions_test <- list()

for (loc in locations) {
  res <- analyze_location(loc, data)
  if (!is.null(res)) {
    all_results[[loc]] <- res$full_results
    all_predictions_test[[loc]] <- res$predictions_test_only
  }
}


final_results <- bind_rows(all_results)

final_results$sig_arima <- ifelse(
  final_results$val >= final_results$prelower_arima & final_results$val <= final_results$preupper_arima,
  0, 1)

final_results$change_arima <- ifelse(
  final_results$val > final_results$prediction_arima, 1,
  ifelse(final_results$val < final_results$prediction_arima, -1, 0)
)


final_results <- final_results %>%
  mutate(rc_arima = (val - prediction_arima) / prediction_arima * 100)


lag <- 4
final_results_all <- final_results %>%
  filter(year >= 1990 + lag & year <= 2021)



final_results_2021 <- final_results %>%
  filter(year >= 2020 & year <= 2021)



final_predictions_test <- bind_rows(all_predictions_test)
final_model_params <- bind_rows(model_params_list)

dir.create("XXXX", showWarnings = FALSE)
write.xlsx(final_results_all, file = ".xlsx", rowNames = FALSE)
write.xlsx(final_results_2021, file = ".xlsx", rowNames = FALSE)
