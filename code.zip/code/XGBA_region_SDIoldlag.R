setwd("/Users/qinchenyuan/Desktop/")

packages <- c("tidyverse", "forecast", "openxlsx", "xgboost", "readxl")
new_packages <- packages[!(packages %in% installed.packages()[,"Package"])]
if(length(new_packages)) install.packages(new_packages)
lapply(packages, library, character.only = TRUE)


data <- read_excel("neodistotal_region_SDI_pop_old.xlsx")


analyze_location <- function(location_name, data) {
  cat("Processing:", location_name, "\n")
  

  Materdis <- data %>%
    filter(
      location == location_name,
      age == "Birth",
      cause == "Neonatal preterm birth",
      metric == "Rate",
      year >= 1990 & year <= 2021
    ) %>%
    arrange(year)

  if (nrow(Materdis) < 30) return(NULL)
  if (any(is.na(Materdis$val)) || any(!is.finite(Materdis$val))) return(NULL)
  if (any(is.na(Materdis$SDI)) || any(!is.finite(Materdis$SDI))) return(NULL)
  

  ts_data <- ts(Materdis$val, start = 1990, frequency = 1)
  train_1990_2016 <- window(ts_data, start = 1990, end = 2016)
  train_1994_2016 <- window(ts_data, start = 1994, end = 2016)
  test_data <- window(ts_data, start = 2017, end = 2019)
  train_1990_2019 <- window(ts_data, start = 1990, end = 2019)
  test_2020_2021 <- window(ts_data, start = 2020, end = 2021)
  

  SDI_1990_2016 <- Materdis %>% filter(year <= 2016) %>% select(SDI, old) %>% as.matrix()
  SDI_test <- Materdis %>% filter(year >= 2017 & year <= 2019) %>% select(SDI, old) %>% as.matrix()
  SDI_1990_2019 <- Materdis %>% filter(year <= 2019) %>% select(SDI, old) %>% as.matrix()
  SDI_2020_2021 <- Materdis %>% filter(year >= 2020 & year <= 2021) %>% select(SDI, old) %>% as.matrix()
  

  model_arimax <- tryCatch({
    auto.arima(train_1990_2016, xreg = SDI_1990_2016, seasonal = FALSE,
               ic = "aic", method = "ML", stepwise = FALSE,
               trace = FALSE, approximation = FALSE)
  }, error = function(e) {
    cat("ARIMAX model fitting failed for", location_name, ":", conditionMessage(e), "\n")
    return(NULL)
  })
  if (is.null(model_arimax)) return(NULL)
  
  forecast_arima <- forecast(model_arimax, xreg = SDI_test, h = length(test_data), level = 95)
  test_arima <- forecast_arima$mean  
  

  res_train <- residuals(model_arimax)
  res_test <- as.numeric(test_data - test_arima)
  

  ts_data <- ts(Materdis$val, start = 1990, frequency = 1)
  train_1990_2016 <- window(ts_data, start = 1990, end = 2016)
  train_1994_2016 <- window(ts_data, start = 1994, end = 2016)
  test_data <- window(ts_data, start = 2017, end = 2019)
  train_1990_2019 <- window(ts_data, start = 1990, end = 2019)
  test_2020_2021 <- window(ts_data, start = 2020, end = 2021)
  
  res_all <- c(res_train, res_test)
  SDI_all <- Materdis$SDI  #！！！！
  old_all <- Materdis$old#！！！
  

  create_lag_features <- function(x, lag = 4) {
    df <- tibble(Value = as.numeric(x))
    for (i in 1:lag) {
      df <- df %>% mutate(!!paste0("lag_", i) := dplyr::lag(Value, n = i))
    }
    return(df)
  }
  
  lag <- 4

  res_all_lagged <- create_lag_features(res_all, lag = lag) %>% na.omit()
  

  total_length <- length(res_all)
  train_length <- length(res_train)
  test_length <- length(res_test)
  

  SDI_all_lagged <- SDI_all[(lag + 1):total_length]
  old_all_lagged <- old_all[(lag + 1):total_length]
  

  train_idx <- 1:(train_length - lag)
  test_idx <- (train_length - lag + 1):(train_length - lag + test_length)
  

  X_train <- as.matrix(cbind(SDI = SDI_all_lagged[train_idx],
                             old = old_all_lagged[train_idx],
                             res_all_lagged[train_idx, -1]))
  y_train <- res_all_lagged$Value[train_idx]
  

  X_test <- as.matrix(cbind(SDI = SDI_all_lagged[test_idx],
                            old = old_all_lagged[test_idx],
                            res_all_lagged[test_idx, -1]))
  

  dtrain <- xgb.DMatrix(data = X_train, label = y_train)
  dtest <- xgb.DMatrix(data = X_test)
  
  

  coarse_param_grid <- expand.grid(
    eta = c(0.01, 0.05, 0.1),
    max_depth = c(3, 5, 7),
    subsample = c(0.6, 0.8, 1),
    colsample_bytree = c(0.6, 0.8, 1),
    KEEP.OUT.ATTRS = FALSE,
    stringsAsFactors = FALSE
  )

  cv_rmse <- function(params, dtrain) {
    cv <- xgb.cv(
      params = params,
      data = dtrain,
      nrounds = 100,
      nfold = 5,
      showsd = TRUE,
      early_stopping_rounds = 10,
      maximize = FALSE,
      verbose = 0
    )
    return(min(cv$evaluation_log$test_rmse_mean))
  }
  

  best_rmse <- Inf
  best_params <- list()
  set.seed(123)
  for (i in 1:nrow(coarse_param_grid)) {
    params <- list(
      objective = "reg:squarederror",
      eta = coarse_param_grid$eta[i],
      max_depth = coarse_param_grid$max_depth[i],
      subsample = coarse_param_grid$subsample[i],
      colsample_bytree = coarse_param_grid$colsample_bytree[i],
      seed = 123
    )
    rmse_val <- cv_rmse(params, dtrain)
    if (rmse_val < best_rmse) {
      best_rmse <- rmse_val
      best_params <- params
    }
  }
  

  fine_param_grid <- expand.grid(
    eta = seq(max(0.001, best_params$eta - 0.02), min(0.3, best_params$eta + 0.02), by = 0.01),
    max_depth = unique(pmax(1, c(best_params$max_depth - 1, best_params$max_depth, best_params$max_depth + 1))),
    subsample = seq(max(0.5, best_params$subsample - 0.1), min(1, best_params$subsample + 0.1), by = 0.1),
    colsample_bytree = seq(max(0.5, best_params$colsample_bytree - 0.1), min(1, best_params$colsample_bytree + 0.1), by = 0.1),
    KEEP.OUT.ATTRS = FALSE,
    stringsAsFactors = FALSE
  )
  

  set.seed(123)
  for (i in 1:nrow(fine_param_grid)) {
    params <- list(
      objective = "reg:squarederror",
      eta = fine_param_grid$eta[i],
      max_depth = fine_param_grid$max_depth[i],
      subsample = fine_param_grid$subsample[i],
      colsample_bytree = fine_param_grid$colsample_bytree[i]
    )
    rmse_val <- cv_rmse(params, dtrain)
    if (rmse_val < best_rmse) {
      best_rmse <- rmse_val
      best_params <- params
    }
  }
  

  set.seed(123)
  xgb_model <- xgb.train(params = best_params, data = dtrain, nrounds = 50, verbose = 0)
  
  residuals_pred <- predict(xgb_model, dtest)
  final_predictions <- as.numeric(test_arima + residuals_pred)
  
  rmse_val <- sqrt(mean((final_predictions - test_data)^2))
  mae_val <- mean(abs(final_predictions - test_data))
  mape_val <- mean(abs((final_predictions - test_data)/test_data)) * 100
  

  fitted_xgb_9416 <- predict(xgb_model, dtrain)
  fitted_arima9016 <- fitted(model_arimax)
  fitted_arima_9416 <- fitted_arima9016[5:27] 
  final_fitted9416 <- fitted_arima_9416 + fitted_xgb_9416
  

  white_noise <- FALSE
  residuals_combined <- train_1994_2016 - final_fitted9416
  lb_test <- Box.test(residuals_combined, lag = 5, type = "Ljung-Box")
  white_noise <- lb_test$p.value > 0.05
  

  model_fixed <- tryCatch({
    Arima(train_1990_2019,
          order = arimaorder(model_arimax),
          xreg = SDI_1990_2019,
          method = "ML")
  }, error = function(e) {
    cat("Model fitting failed for", location_name, ":", conditionMessage(e), "\n")
    return(NULL)
  })
  
  

  if (is.null(model_fixed)) return(NULL)
  
  predictions_2020_2021 <- rep(NA, 2)
  
  if (!is.null(model_fixed)) {
    forecast_arima_future <- forecast(model_fixed, xreg = SDI_2020_2021, h = 2, level = 95)
    pred_arima_future <- as.numeric(forecast_arima_future$mean)
    forecast_arima_future_upper <- forecast_arima_future$upper[, 1]
    forecast_arima_future_lower <- forecast_arima_future$lower[, 1]
    se_arima_future <- (forecast_arima_future_upper - forecast_arima_future_lower) / (2 * 1.96)
    

    residuals_train_full <- residuals(model_fixed)
    SDI_train_full <- Materdis$SDI[Materdis$year <= 2019]
    old_train_full <- Materdis$old[Materdis$year <= 2019]
    
    lag <- 4

    residuals_train_full_lagged <- create_lag_features(residuals_train_full, lag = lag) %>% na.omit()
    

    total_full_length <- length(residuals_train_full)
    
    

    SDI_train_lagged <- SDI_train_full[(lag + 1):total_full_length]
    old_train_lagged <- old_train_full[(lag + 1):total_full_length]
    

    lagged_matrix <- residuals_train_full_lagged[, -1] %>% mutate(across(everything(), as.numeric))
    X_train_full <- as.matrix(cbind(SDI = SDI_train_lagged,
                                    old = old_train_lagged,
                                    lagged_matrix))
    y_train_full <- residuals_train_full_lagged$Value
    
    

    n_bootstrap <- 1000
    future_steps <- 2
    future_SDI <- Materdis$SDI[Materdis$year >= 2020 & Materdis$year <= 2021]
    future_old <- Materdis$old[Materdis$year >= 2020 & Materdis$year <= 2021]

    bootstrap_preds_future <- matrix(NA, nrow = n_bootstrap, ncol = future_steps)
    bootstrap_fitted_train <- matrix(NA, nrow = n_bootstrap, ncol = nrow(X_train_full))
    
    set.seed(123)
    for (b in 1:n_bootstrap) {

      boot_idx <- sample(1:nrow(X_train_full), size = nrow(X_train_full), replace = TRUE)

      dtrain_boot <- xgb.DMatrix(data = X_train_full[boot_idx, ], label = y_train_full[boot_idx])

      xgb_model_boot <- xgb.train(
        params = best_params, 
        data = dtrain_boot, 
        nrounds = 50, 
        verbose = 0)
      

      dtrain_full <- xgb.DMatrix(data = X_train_full, label = y_train_full)
      fitted_vals <- predict(xgb_model_boot, newdata = dtrain_full)
      bootstrap_fitted_train[b, ] <- fitted_vals  
      
      

      preds <- numeric(future_steps)
      lag_values <- tail(residuals_train_full, lag)
      
      for (i in 1:future_steps) {
        x_input <- c(SDI = future_SDI[i],
                     old = future_old[i],
                     lag_values)
        preds[i] <- predict(xgb_model_boot, matrix(x_input, nrow = 1))
        lag_values <- c(tail(lag_values, lag - 1), preds[i])
      }
      bootstrap_preds_future[b, ] <- preds
    }
    
    pred_xgb_future <- colMeans(bootstrap_preds_future)
    xgb_lower_future <- apply(bootstrap_preds_future, 2, quantile, probs = 0.025)
    xgb_upper_future <- apply(bootstrap_preds_future, 2, quantile, probs = 0.975)
    se_xgb_future <- (xgb_upper_future - xgb_lower_future) / (2 * 1.96)
    
    predictions_2020_2021 <- as.numeric(pred_arima_future + pred_xgb_future)
    se_combined_future <- sqrt(se_arima_future^2 + se_xgb_future^2)
    combined_lower_future <- predictions_2020_2021 - 1.96 * se_combined_future
    combined_upper_future <- predictions_2020_2021 + 1.96 * se_combined_future
    
    

    fitted_arima_values <- fitted(model_fixed)[5:30]
    arima_residuals <- residuals(model_fixed)[5:30]
    se_arima_fit <- sqrt(mean(arima_residuals^2)) 
    
    fitted_train_mean <- colMeans(bootstrap_fitted_train)
    fitted_train_lower <- apply(bootstrap_fitted_train, 2, quantile, probs = 0.025)
    fitted_train_upper <- apply(bootstrap_fitted_train, 2, quantile, probs = 0.975)
    
    fitted_xgb_values <- fitted_train_mean
    se_xgb_fit <- (fitted_train_upper - fitted_train_lower) / (2 * 1.96)
    
    fitted_values <- as.numeric(fitted_arima_values + fitted_xgb_values)  
    se_combined_fit <- sqrt(se_arima_fit^2 + se_xgb_fit^2)
    combined_lower_fit <- fitted_values - 1.96 * se_combined_fit
    combined_upper_fit <- fitted_values + 1.96 * se_combined_fit
  }
  
  years <- 1994:2021 
  
  actual_val <- Materdis$val[Materdis$year %in% years]
  actual_upper <- Materdis$upper[Materdis$year %in% years]
  actual_lower <- Materdis$lower[Materdis$year %in% years]
  all_SDI <- Materdis$SDI[Materdis$year %in% years]

  all_old <- Materdis$old[Materdis$year %in% years]
  

  all_predictions <- c(as.numeric(fitted_values), as.numeric(predictions_2020_2021))
  all_prelower <- c(as.numeric(combined_lower_fit), as.numeric(combined_lower_future))
  all_preupper <- c(as.numeric(combined_upper_fit), as.numeric(combined_upper_future))
  
  RMSE_all <- rep(rmse_val, length(years))
  MAE_all <- rep(mae_val, length(years))
  MAPE_all <- rep(mape_val, length(years))
  white_noise <- rep(white_noise, length(years))
  
  results_df <- data.frame(
    location = location_name,
    sex = "Both",
    age = "Birth",
    cause = "Neonatal preterm birth",
    year = years,
    val = actual_val,
    upper = actual_upper,
    lower = actual_lower,
    SDI = all_SDI,
    # old = all_old,
    old = all_old,
    prediction_axgb = all_predictions,
    preupper_axgb = all_preupper,
    prelower_axgb = all_prelower,  
    RMSE_axgb = RMSE_all,
    MAE_axgb = MAE_all,
    MAPE_axgb = MAPE_all,
    noise_axgb = white_noise
  )
  
  predictions_test_df <- data.frame(
    location = location_name,
    year = 2017:2019,
    prediction_2017_2019 = final_predictions
  )
  
  return(list(full_results = results_df, predictions_test_only = predictions_test_df))
}


unique_locations <- unique(data$location)
results_list <- lapply(unique_locations, function(loc) analyze_location(loc, data))
results_list <- results_list[!sapply(results_list, is.null)]

full_data <- do.call(rbind, lapply(results_list, `[[`, "full_results"))
test_predictions <- do.call(rbind, lapply(results_list, `[[`, "predictions_test_only"))

final_results <- full_data

final_results$sig_axgb <- ifelse(
  final_results$val >= final_results$prelower_axgb & final_results$val <= final_results$preupper_axgb,
  0, 1)

final_results$change_axgb <- ifelse(
  final_results$val > final_results$prediction_axgb, 1,
  ifelse(final_results$val < final_results$prediction_axgb, -1, 0))


final_results <- final_results %>%
  mutate(rc_axgb = (val - prediction_axgb) / prediction_axgb * 100)


lag <- 4
final_results_all <- final_results %>%
  filter(year >= 1990 + lag & year <= 2021)


final_results_2021 <- final_results %>%
  filter(year >= 2020 & year <= 2021)


final_predictions_test <- test_predictions


write.xlsx(final_results_all, ".xlsx", rowNames = FALSE)
write.xlsx(final_results_2021, file = ".xlsx", rowNames = FALSE)
