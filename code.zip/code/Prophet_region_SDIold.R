library(readxl)
library(dplyr)
library(prophet)
library(Metrics)
library(openxlsx)

setwd("/Users/qinchenyuan/Desktop/")


set.seed(123)

data <- read_excel("neodistotal_region_SDI_pop_old.xlsx")


param_grid <- expand.grid(
  changepoint_prior_scale = c(0.01, 0.05, 0.1, 0.5),
  changepoint_range = c(0.7, 0.8, 0.9, 0.95, 1.0)
)

analyze_location_prophet <- function(location_name, data) {
  cat("Processing:", location_name, "\n")
  
  Materdis <- data %>%
    filter(
      location == location_name,
      age == "Birth",
      cause == "Neonatal preterm birth",
      metric == "Rate",
      year >= 1990 & year <= 2021
    ) %>%
    arrange(year)
  

  if (nrow(Materdis) < 30) return(NULL)
  if (any(is.na(Materdis$val)) || any(!is.finite(Materdis$val))) return(NULL)
  if (any(is.na(Materdis$SDI)) || any(!is.finite(Materdis$SDI))) return(NULL)
  if (any(is.na(Materdis$old)) || any(!is.finite(Materdis$old))) return(NULL)
  
  df <- data.frame(
    ds = as.Date(paste0(Materdis$year, "-01-01")),
    y = Materdis$val,
    SDI = Materdis$SDI,
    old = Materdis$old
  )
  

  train_df <- df %>% filter(format(ds, "%Y") %>% as.numeric() >= 1990 & format(ds, "%Y") %>% as.numeric() <= 2016)

  test_df <- df %>% filter(format(ds, "%Y") %>% as.numeric() >= 2017 & format(ds, "%Y") %>% as.numeric() <= 2019)
  future_years <- 2
  
  best_rmse <- Inf
  best_params <- NULL
  best_model <- NULL
  best_forecast_test <- NULL

  for (i in 1:nrow(param_grid)) {
    params <- param_grid[i, ]
    
    m <- prophet(
      yearly.seasonality = FALSE,
      daily.seasonality = FALSE,
      weekly.seasonality = FALSE,
      changepoint.prior.scale = params$changepoint_prior_scale,
      changepoint.range = params$changepoint_range,
      n.changepoints = 10,
      interval.width = 0.95
    )
    
    m <- add_regressor(m, "SDI")
    m <- add_regressor(m, "old")
    
    m <- fit.prophet(m, train_df)
    
    periods_test <- nrow(test_df)
    future_test <- make_future_dataframe(m, periods = periods_test, freq = "year")
    future_test <- future_test %>%
      left_join(df %>% select(ds, SDI, old), by = "ds")
    
    forecast_test <- predict(m, future_test)
    
    pred_test <- forecast_test %>%
      filter(format(ds, "%Y") %>% as.numeric() >= 2017 & format(ds, "%Y") %>% as.numeric() <= 2019) %>%
      pull(yhat)
    
    current_rmse <- rmse(test_df$y, pred_test)
    
    if (current_rmse < best_rmse) {
      best_rmse <- current_rmse
      best_params <- params
      best_model <- m
      best_forecast_test <- forecast_test
    }
  }
  
 
  train_all_df <- df %>% filter(format(ds, "%Y") %>% as.numeric() >= 1990 & format(ds, "%Y") %>% as.numeric() <= 2019)
  
  m_all <- prophet(
    yearly.seasonality = FALSE,
    daily.seasonality = FALSE,
    weekly.seasonality = FALSE,
    changepoint.prior.scale = best_params$changepoint_prior_scale,
    changepoint.range = best_params$changepoint_range,
    n.changepoints = 10,
    interval.width = 0.95
  )
  
  m_all <- add_regressor(m_all, "SDI")
  m_all <- add_regressor(m_all, "old")
  
  m_all <- fit.prophet(m_all, train_all_df)
  
  future_2020_2021 <- make_future_dataframe(m_all, periods = future_years, freq = "year")
  future_2020_2021 <- future_2020_2021 %>%
    left_join(df %>% select(ds, SDI, old), by = "ds")
  
  forecast_2020_2021 <- predict(m_all, future_2020_2021)
  

  fitted_df <- predict(m_all, train_all_df) %>%
    select(ds, yhat, yhat_lower, yhat_upper)

  pred_df <- forecast_2020_2021 %>%
    filter(format(ds, "%Y") %>% as.numeric() >= 2020 & format(ds, "%Y") %>% as.numeric() <= 2021) %>%
    select(ds, yhat, yhat_lower, yhat_upper)
  

  all_pred_df <- bind_rows(fitted_df, pred_df) %>%
    arrange(ds)
  

  

  pred_test_final <- best_forecast_test %>%
    filter(format(ds, "%Y") %>% as.numeric() >= 2017 & format(ds, "%Y") %>% as.numeric() <= 2019) %>%
    pull(yhat)
  
  mae_val <- mae(test_df$y, pred_test_final)
  mape_val <- mean(abs((pred_test_final - test_df$y) / test_df$y)) * 100
  

  fitted_train_df <- predict(best_model, train_df)
  residuals <- train_df$y - fitted_train_df$yhat

  lb_test <- Box.test(residuals, lag = 5, type = "Ljung-Box")
  white_noise <- lb_test$p.value > 0.05
  
  
  years <- 1990:2021
  
  
  actual_val <- Materdis$val[Materdis$year %in% years]
  actual_upper <- Materdis$upper[Materdis$year %in% years]
  actual_lower <- Materdis$lower[Materdis$year %in% years]
  all_SDI <- Materdis$SDI[Materdis$year %in% years]
  all_old <- Materdis$old[Materdis$year %in% years]
  

  RMSE_all <- rep(best_rmse, length(years))
  MAE_all <- rep(mae_val, length(years))
  MAPE_all <- rep(mape_val, length(years))
  white_noise <- rep(white_noise, length(years)) 
  
  
  results_df <- data.frame(
    location = location_name,
    sex = "Both",
    age = "Birth",
    cause = "Neonatal preterm birth",
    year = years,
    val = actual_val,
    upper = actual_upper,
    lower = actual_lower,
    SDI = all_SDI,
    old = all_old,
    prediction_prophet = all_pred_df$yhat,
    preupper_prophet = all_pred_df$yhat_upper,
    prelower_prophet = all_pred_df$yhat_lower,
    RMSE_prophet = RMSE_all,
    MAE_prophet = MAE_all,
    MAPE_prophet = MAPE_all,
    noise_prophet = white_noise
  )
  
  predictions_test_df <- data.frame(
    location = location_name,
    year = 2017:2019,
    prediction_2017_2019 = pred_test_final
  )
  
  return(list(full_results = results_df, predictions_test_only = predictions_test_df))
}

locations <- unique(data$location)
all_results <- list()
all_predictions_test <- list()

for (loc in locations) {
  res <- analyze_location_prophet(loc, data)
  if (!is.null(res)) {
    all_results[[loc]] <- res$full_results
    all_predictions_test[[loc]] <- res$predictions_test_only
  }
}

final_results <- bind_rows(all_results)



final_results$sig_prophet <- ifelse(
  final_results$val >= final_results$prelower_prophet & final_results$val <= final_results$preupper_prophet,
  0, 1)

final_results$change_prophet <- ifelse(
  final_results$val > final_results$prediction_prophet, 1,
  ifelse(final_results$val < final_results$prediction_prophet, -1, 0))

final_results <- final_results %>%
  mutate(rc_prophet = (val - prediction_prophet) / prediction_prophet * 100)


lag <- 4
final_results_all <- final_results %>%
  filter(year >= 1990 + lag & year <= 2021)


final_results_2021 <- final_results %>%
  filter(year >= 2020 & year <= 2021)


final_predictions_test <- bind_rows(all_predictions_test)

write.xlsx(final_results_all, ".xlsx", rowNames = FALSE)
write.xlsx(final_results_2021, file = ".xlsx", rowNames = FALSE)
