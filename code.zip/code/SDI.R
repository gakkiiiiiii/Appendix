setwd("/Users/qinchenyuan/Desktop/")
library(dplyr)
library(forecast)
library(readxl)
library(openxlsx)
library(tidyr)


df <- read_excel("SDI2021.xlsx")
df_long <- pivot_longer(df, cols = 2:31, names_to = "year", values_to = "SDI") %>%
  mutate(year = as.numeric(year)) %>%
  filter(!is.na(year))


loc_df <- read_excel("location.xlsx") %>%
  filter(!location %in% c("Low-middle SDI", "Middle SDI", "High SDI", 
                          "High-middle SDI", "Low SDI"))


df_SDI <- left_join(loc_df, df_long, by = "location")


sdi_forecast <- data.frame(location = character(),
                           year = integer(),
                           SDI = double())

locations <- unique(df_SDI$location)

for (loc in locations) {
  df_loc <- df_SDI %>% filter(location == loc) %>% arrange(year)
  

  if (nrow(df_loc) < 5) next
  

  sdi_ts <- ts(df_loc$SDI, start = min(df_loc$year), frequency = 1)

  fit <- auto.arima(sdi_ts, ic = "aic", method = "ML")
  
  

  fcast <- forecast(fit, h = 2)
  

  sdi_forecast <- rbind(
    sdi_forecast,
    data.frame(location = loc,
               year = 2020:2021,
               SDI = as.numeric(fcast$mean))
  )
}


df_complete <- bind_rows(
  df_SDI %>% select(location, year, SDI),
  sdi_forecast
) %>% arrange(location, year)


write.xlsx(df_complete, file = "SDI_1990_2021_forecast.xlsx", overwrite = TRUE)


non_white_noise <- data.frame(location = character(),
                              p_value = double(),
                              stringsAsFactors = FALSE)

for (loc in locations) {
  df_loc <- df_SDI %>% filter(location == loc) %>% arrange(year)
  
  if (nrow(df_loc) < 5) next
  
  sdi_ts <- ts(df_loc$SDI, start = min(df_loc$year), frequency = 1)
  
  fit <- auto.arima(sdi_ts, ic = "aic", method = "ML")
  

  lb_test <- Box.test(fit$residuals, lag = 10, type = "Ljung-Box")
  

  if (lb_test$p.value <= 0.05) {
    non_white_noise <- rbind(non_white_noise,
                             data.frame(location = loc,
                                        p_value = lb_test$p.value))
  }
}


print(non_white_noise)
